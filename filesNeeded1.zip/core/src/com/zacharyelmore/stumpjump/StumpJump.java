package com.zacharyelmore.stumpjump;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;

import java.util.Random;

public class StumpJump extends ApplicationAdapter {
	SpriteBatch batch;
	Texture background;
	ShapeRenderer shapeRenderer;

	Texture[] foxes;
	int runState = 0;
	int time = 0;
	float foxY = 0;
	float velocity = 0;
	Rectangle foxRec;
	int score = 0;
	int scoringTube = 0;
	BitmapFont font;

	int gameState = 0;
	float gravity = 2;

	Texture gameOver;

	//Texture topTube;
	Texture bottomTube;
	float gap = 400;
	float maxTubeOffSet;
	Random randomGen;
	float tubeVelocity = 10;
	int numberOfTubes = 4;
	float[] tubeX = new float[numberOfTubes];
	float[] tubeOffSet = new float[numberOfTubes];
	float distanceBetweenTubes;
	//Rectangle[] topTubeRectangle;
	Rectangle[] bottomTubeRectangle;

	@Override
	public void create () {
		batch = new SpriteBatch();
		background = new Texture("background.png");
		gameOver = new Texture("gameOver1.png");
		shapeRenderer = new ShapeRenderer();
		foxRec = new Rectangle();
		font = new BitmapFont();
		font.setColor(Color.WHITE);
		font.getData().setScale(10);

		foxes = new Texture[3];
		foxes[0] = new Texture("fox1.png");
		foxes[1] = new Texture("fox2.png");
		foxes[2] = new Texture("fox3.png");

		//topTube = new Texture("toptube.png");
		bottomTube = new Texture("stump.png");
		maxTubeOffSet = Gdx.graphics.getHeight() / 2 - gap / 2 - 100;
		randomGen = new Random();
		distanceBetweenTubes = Gdx.graphics.getWidth() * 3 / 4;
		//topTubeRectangle = new Rectangle[numberOfTubes];
		bottomTubeRectangle = new Rectangle[numberOfTubes];

		startGame();

	}

	public void startGame(){
		foxY = 0;

		for(int i = 0; i < numberOfTubes; i++){
			//tubeOffSet[i] = (randomGen.nextFloat() - 0.5f) * (Gdx.graphics.getHeight() - gap - 200);   //Randomizes the height of tubes
			tubeX[i] = Gdx.graphics.getWidth() / 2 - bottomTube.getWidth() / 2 + Gdx.graphics.getWidth() + i * distanceBetweenTubes;
			//topTubeRectangle[i] = new Rectangle();
			bottomTubeRectangle[i] = new Rectangle();
		}
	}

	@Override
	public void render () {

		batch.begin();

		//Splash screen goes here

		 if(gameState == 0)
		 	background = new Texture("splash.png");
		 else
			background = new Texture("background.png");

		batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

		if (gameState == 1) {

			if(tubeX[scoringTube] < Gdx.graphics.getWidth() / 4){
				score++;

				Gdx.app.log("Score", String.valueOf(score));

				if(scoringTube < numberOfTubes - 1){
					scoringTube++;
				}
				else {
					scoringTube = 0;
				}


				if(score % 3 == 0){
					tubeVelocity++;
				}
			}

			if(score < 50) {
				if (foxY == 0) {
					if (Gdx.input.justTouched()) {
						velocity = -30;
					}
				}
			}
			else{
				if (foxY == 0 || foxY <= 75) {
					if (Gdx.input.justTouched()) {
						velocity = -30;
					}
				}
			}

			for (int i = 0; i < numberOfTubes; i++) {

				if (tubeX[i] < - bottomTube.getWidth()) {
					tubeX[i] += numberOfTubes * distanceBetweenTubes;
					tubeOffSet[i] = (randomGen.nextFloat() - 0.5f) * (Gdx.graphics.getHeight() - gap - 200);
				} else {
					tubeX[i] = tubeX[i] - tubeVelocity;
				}

				//batch.draw(topTube, tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffSet[i]);
				batch.draw(bottomTube, tubeX[i], 0 /*Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight()*/ /*+ tubeOffSet[i]*/);
				//topTubeRectangle[i] = new Rectangle(tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffSet[i], topTube.getWidth(), topTube.getHeight());
				bottomTubeRectangle[i] = new Rectangle(tubeX[i], 0/*Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight() + tubeOffSet[i]*/, bottomTube.getWidth(), bottomTube.getHeight());
			}

			if (foxY > 0 || velocity < 0) {
				velocity = velocity + gravity;
				foxY -= velocity;
			}

		}
		else if(gameState == 0){
			if (Gdx.input.justTouched()) {
				gameState = 1;
			}
		}
		else if(gameState == 2){
			batch.draw(gameOver, Gdx.graphics.getWidth() / 2 - gameOver.getWidth() / 2, Gdx.graphics.getHeight() / 2 - gameOver.getHeight() / 2);

			if (Gdx.input.justTouched()) {
				gameState = 1;
				startGame();
				score = 0;
				scoringTube = 0;
				velocity = 0;
				tubeVelocity = 10;
			}
		}


		if (time == 5) {
			if (runState == 0)
				runState = 1;
			else if(runState == 1)
				runState = 2;
			else {
				runState = 0;
			}
			time = 0;
		} else {
			time++;
		}

		batch.draw(foxes[runState], Gdx.graphics.getWidth() / 4 - foxes[runState].getWidth() / 2, foxY);

		font.draw(batch, String.valueOf(score), 100, 200);

		batch.end();

		foxRec.set(Gdx.graphics.getWidth() / 4 - foxes[runState].getWidth() / 4, foxY + foxes[runState].getHeight() / 2, foxes[runState].getWidth() / 4, foxes[runState].getHeight());

		//shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
		//shapeRenderer.setColor(Color.RED);
		//shapeRenderer.rect(foxRec.x, foxRec.y, Gdx.graphics.getWidth() / 4 - foxes[runState].getWidth() / 2, foxY);

		for (int i = 0; i < numberOfTubes; i++){
			//	shapeRenderer.rect(tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffSet[i], topTube.getWidth(), topTube.getHeight());
			//	shapeRenderer.rect(tubeX[i], Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight() /*+ tubeOffSet[i]*/, bottomTube.getWidth(), bottomTube.getHeight());

			if(/*Intersector.overlaps(foxRec, topTubeRectangle[i]) ||*/ Intersector.overlaps(foxRec, bottomTubeRectangle[i])){
				gameState = 2;
			}
		}



		shapeRenderer.end();
	}
}
